/*
 * ex3.c
 *
 *  Created on: Mar 13, 2023
 *      Author: KARIM
 *  C Program to Add Two Integers
 */

#include<stdio.h>

int main(){
	int x,y;
	printf("Enter two numbers: \n");
	fflush(stdin); fflush(stdout);
	scanf("%d %d",&x,&y);

	int sum = x+y;
	printf("Sum is %d",sum);

	return 0;
}
