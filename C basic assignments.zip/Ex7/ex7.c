/*
 * ex7.c
 *
 *  Created on: Mar 13, 2023
 *      Author: KARIM
 *  Swap Two Numbers without temp variable
 */


