/*
 * Ex6.c
 *
 *  Created on: Mar 14, 2023
 *      Author: KARIM
 *  Find a factorial of a number
 */

#include<stdio.h>

int main(){
	int x;
	int fact=1;
	printf("Enter an integer: \n");
	fflush(stdin); fflush(stdout);
	scanf("%d",&x);

	if( x>0 ){
		for(int i=1; i<=x; i++){
			fact *= i;
		}
		printf("Factorial = %d",fact);
	}
	else{
		printf("%d is not has a factorial",x);
	}

	return 0;
}
