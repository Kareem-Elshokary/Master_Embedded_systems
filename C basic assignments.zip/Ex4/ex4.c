/*
 * ex4.c
 *
 *  Created on: Mar 13, 2023
 *      Author: KARIM
 *  C Program to Multiply two Floating Point Numbers
 */

#include<stdio.h>

int main(){
	float x,y;
	printf("Enter two numbers: \n");
	fflush(stdin); fflush(stdout);
	scanf("%f %f",&x,&y);

	float mul = x*y;
	printf("product: %f",mul);

	return 0;
}
